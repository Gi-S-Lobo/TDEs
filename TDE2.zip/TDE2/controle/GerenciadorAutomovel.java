package controle;

import dominio.Automovel;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class GerenciadorAutomovel {
    private ArrayList<Automovel> automoveis = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);
    private final String ARQUIVO = "automoveis.txt";

    public static void main(String[] args) {
        GerenciadorAutomovel gerenciador = new GerenciadorAutomovel();
        gerenciador.executar();
    }

    public void executar() {
        carregarDados();
        menuPrincipal();
    }

    private void menuPrincipal() {
        int opcao;
        do {
            System.out.println("\n=== MENU PRINCIPAL ===");
            System.out.println("1. Cadastrar automóvel");
            System.out.println("2. Listar automóveis");
            System.out.println("3. Buscar automóvel");
            System.out.println("4. Remover automóvel");
            System.out.println("5. Salvar e sair");
            System.out.print("Opção: ");
            
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch(opcao) {
                case 1: cadastrar(); break;
                case 2: listar(); break;
                case 3: buscar(); break;
                case 4: remover(); break;
                case 5: salvar(); break;
                default: System.out.println("Opção inválida!");
            }
        } while(opcao != 5);
    }

    private void cadastrar() {
        System.out.println("\n--- CADASTRAR ---");
        System.out.print("Placa: ");
        String placa = scanner.nextLine();
        
        if(buscarPorPlaca(placa) != null) {
            System.out.println("Placa já cadastrada!");
            return;
        }
        
        System.out.print("Modelo: ");
        String modelo = scanner.nextLine();
        
        System.out.print("Marca: ");
        String marca = scanner.nextLine();
        
        System.out.print("Ano: ");
        int ano = scanner.nextInt();
        
        System.out.print("Valor: R$");
        double valor = scanner.nextDouble();
        scanner.nextLine();
        
        Automovel novo = new Automovel(placa, modelo, marca, ano, valor);
        automoveis.add(novo);
        System.out.println("Cadastrado com sucesso!");
    }

    private void listar() {
        System.out.println("\n--- LISTAGEM ---");
        
        if(automoveis.isEmpty()) {
            System.out.println("Nenhum automóvel cadastrado.");
            return;
        }
        
       
        for(int i = 0; i < automoveis.size()-1; i++) {
            for(int j = i+1; j < automoveis.size(); j++) {
                if(automoveis.get(i).getPlaca().compareTo(automoveis.get(j).getPlaca()) > 0) {
                    Automovel temp = automoveis.get(i);
                    automoveis.set(i, automoveis.get(j));
                    automoveis.set(j, temp);
                }
            }
        }
        
        for(Automovel auto : automoveis) {
            System.out.println(auto);
        }
    }

    private void buscar() {
        System.out.println("\n--- BUSCAR ---");
        System.out.print("Placa: ");
        String placa = scanner.nextLine();
        
        Automovel encontrado = buscarPorPlaca(placa);
        if(encontrado != null) {
            System.out.println(encontrado);
        } else {
            System.out.println("Automóvel não encontrado!");
        }
    }

    private void remover() {
        System.out.println("\n--- REMOVER ---");
        System.out.print("Placa: ");
        String placa = scanner.nextLine();
        
        Automovel paraRemover = buscarPorPlaca(placa);
        if(paraRemover != null) {
            automoveis.remove(paraRemover);
            System.out.println("Removido com sucesso!");
        } else {
            System.out.println("Automóvel não encontrado!");
        }
    }

    private Automovel buscarPorPlaca(String placa) {
        for(Automovel auto : automoveis) {
            if(auto.getPlaca().equalsIgnoreCase(placa)) {
                return auto;
            }
        }
        return null;
    }

    private void carregarDados() {
        try (BufferedReader br = new BufferedReader(new FileReader(ARQUIVO))) {
            String linha;
            while((linha = br.readLine()) != null) {
                String[] dados = linha.split(",");
                if(dados.length == 5) {
                    String placa = dados[0];
                    String modelo = dados[1];
                    String marca = dados[2];
                    int ano = Integer.parseInt(dados[3]);
                    double valor = Double.parseDouble(dados[4]);
                    
                    automoveis.add(new Automovel(placa, modelo, marca, ano, valor));
                }
            }
        } catch(FileNotFoundException e) {
            System.out.println("Arquivo não encontrado. Será criado um novo ao salvar.");
        } catch(IOException e) {
            System.out.println("Erro ao ler arquivo: " + e.getMessage());
        }
    }

    private void salvar() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ARQUIVO))) {
            for(Automovel auto : automoveis) {
                bw.write(auto.toCSV());
                bw.newLine();
            }
            System.out.println("Dados salvos com sucesso!");
            System.exit(0);
        } catch(IOException e) {
            System.out.println("Erro ao salvar: " + e.getMessage());
        }
    }
}